#!/bin/bash

export PATH=$PATH:node_modules/bower/bin
