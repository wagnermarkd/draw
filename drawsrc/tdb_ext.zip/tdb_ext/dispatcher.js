// application-wide event dispatcher

define([
  "flux"
], function(flux){
  return new flux.Dispatcher()
})
